from Perro import Perro

perro = Perro(5, 0, "content")
perro.Acariciar()
perro.Jugar()
perro.Jugar()
perro.Jugar()
perro.Comer(3)
perro.Jugar()
perro.dormir(2)
