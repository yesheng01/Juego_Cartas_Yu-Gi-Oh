import random

z = random.randint(0, 9)
print(z)
for i in range(z):
    print("Sheng ", end="")

    