
for i in range(0, 5):
    nombre = input("Introduzca el nombre: ")
    apellido = input("Introduzca el apellido: ")
    dni = input("Introduzca el dni: ")
    telefono = input("Introduzca un numero de telefono")
    print("Datos de un usuario , nombre: " + nombre + ",apellido: " + apellido + ", dni: " + dni + ", telefono: " + telefono)