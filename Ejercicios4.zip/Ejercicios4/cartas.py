class cartas:
    def __init__(self,  Nombre, Tipos, Rareza, Ataque  , Defensa, Vida, Pasiva):
        self.Nombre=Nombre
        self.Tipos=Tipos
        self.Rareza=Rareza
        self.Ataque = Ataque
        self.Defensa=Defensa
        self.Vida=Vida
        self.Pasiva=Pasiva

    def getNombre(self):
            return self.Nombre
    def getTipos(self):
            return self.Tipos
    def getRareza(self):
            return self.Rareza
    def getAtaque(self):
            return self.Ataque
    def getDefensa(self):
            return self.Defensa
    def getVida(self):
            return self.Vida
    def getPasiva(self):
            return self.Pasiva

    def setNombre(self):
            return self.Nombre
    def setTipos(self):
            return self.Tipos
    def setRareza(self):
            return self.Rareza
    def setAtaque(self):
            return self.Ataque
    def setDefensa(self):
            return self.Defensa
    def setVida(self):
            return self.Vida
    def setPasiva(self):
            return self.Pasiva